Thanks for downloading Harvest Summer - Forest pack 16x16!

I'll be updating this tileset, adding new tiles, objects and etc (especially for the full version). Also, Pixelarium is going to be a full bundle with different scenarios and environments. enemies and characters pack. So! stay tuned for future content.

License - Free Version
  - You can only use these assets in non-commercial projects.
  - You can modify the assets.
  - You can not redistribute or resale, even if modified.

Follow me on twitter if you're interested in future content!

https://twitter.com/SnowHexi

Please rate this pack ♥!
https://snowhex.itch.io/harvest-summer-forest-pack/rate

